package org.study.stackoverflow.stackexchange.pojo;

import lombok.Data;

@Data
public class User {

    private Long userId;

    private String userType;

}
